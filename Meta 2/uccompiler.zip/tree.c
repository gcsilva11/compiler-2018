/*
	João Pedro Costa Ferreiro 2014197760
	Guilherme Cardoso Gomes da Silva 2014226354
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tree.h"

AST_struct cria_no(char* valor, char* tipo) {
	AST_struct novo_no = malloc(sizeof(AST_struct));

	novo_no->pai = NULL;
	novo_no->filho = NULL;
	novo_no->irmao = NULL;
	novo_no->no_filhos = 0;

	novo_no->valor = (char*)malloc(strlen(valor)*sizeof(char)+1); // +1 para contar com '\0'
	novo_no->tipo = (char*)malloc(strlen(tipo)*sizeof(char)+1); // +1 para contar com '\0'
	strcpy(novo_no->valor,valor);
	strcpy(novo_no->tipo,tipo);

	return novo_no;
}

void adicionar_filho(AST_struct pai, AST_struct novo_no){
	if (novo_no != NULL){
		pai->filho = novo_no;
		pai->no_filhos++;
		novo_no->pai = pai;
	}
	return;
}

void adicionar_irmao(AST_struct existente, AST_struct novo_no){
	if (existente != NULL && novo_no != NULL){
		
		AST_struct aux = existente;
		
		while(aux->irmao != NULL){
			aux = aux->irmao;
		}

		aux->irmao = novo_no;

		if(novo_no->pai != NULL){
			novo_no->pai = aux->pai;
			novo_no->pai->no_filhos++;
		}
	}
}